import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  Menu, X, Users, MapPin, Trees, Briefcase, ChevronRight, ArrowRight,
  Phone, Mail, MessageCircle, Facebook, Instagram, Youtube,
  Wheat, Store, Mountain, Drama, Beef, Calendar, ChevronLeft,
  Building2, UserCircle2, ScrollText, Landmark,
} from "lucide-react";

import heroImg from "@/assets/hero-village.jpg";
import rumahGadangImg from "@/assets/rumah-gadang.jpg";
import sawahImg from "@/assets/sawah.jpg";
import budayaImg from "@/assets/budaya.jpg";
import sungaiImg from "@/assets/sungai.jpg";
import umkmImg from "@/assets/umkm.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nagari Silongo — Profil Desa Resmi" },
      { name: "description", content: "Website resmi Nagari Silongo, Kecamatan Lubuk Tarok, Kabupaten Sijunjung, Sumatera Barat." },
    ],
  }),
  component: Home,
});

const NAV = [
  { id: "beranda", label: "Beranda" },
  { id: "profil", label: "Profil" },
  { id: "pemerintahan", label: "Pemerintahan" },
  { id: "potensi", label: "Potensi Desa" },
  { id: "wisata", label: "Wisata & Budaya" },
  { id: "berita", label: "Berita" },
  { id: "galeri", label: "Galeri" },
  { id: "kontak", label: "Kontak" },
];

const STATS = [
  { icon: Users, label: "Jumlah Penduduk", value: "4.812", suffix: "Jiwa" },
  { icon: MapPin, label: "Jumlah Jorong", value: "5", suffix: "Jorong" },
  { icon: Trees, label: "Luas Wilayah", value: "32,4", suffix: "km²" },
  { icon: Briefcase, label: "Potensi UMKM", value: "78", suffix: "Unit" },
];

const PEMERINTAHAN = [
  { role: "Wali Nagari", name: "H. Ahmad Dt. Rajo Basa", icon: Landmark,
    bio: "Wali Nagari Silongo periode 2022–2028. Berpengalaman memimpin pembangunan desa dengan pendekatan partisipatif berbasis adat Minangkabau." },
  { role: "Sekretaris Nagari", name: "Yusrizal, S.AP", icon: ScrollText,
    bio: "Sekretaris Nagari yang menangani administrasi pemerintahan, pelayanan publik, dan koordinasi antar perangkat nagari." },
  { role: "Kepala Jorong", name: "Bapak Syamsuar", icon: UserCircle2,
    bio: "Koordinator lima Kepala Jorong di Nagari Silongo yang memimpin pelayanan masyarakat di tingkat jorong." },
  { role: "Bamus Nagari", name: "Dt. Marajo Sutan", icon: Building2,
    bio: "Badan Musyawarah Nagari sebagai mitra Wali Nagari dalam menyusun peraturan dan mengawasi penyelenggaraan pemerintahan." },
];

const POTENSI = [
  { icon: Wheat, title: "Pertanian", desc: "Sawah produktif penghasil padi unggulan, jagung, dan tanaman hortikultura.",
    detail: "Lebih dari 60% lahan Nagari Silongo digunakan untuk pertanian. Sistem irigasi tradisional masih dipelihara berdampingan dengan teknologi modern. Komoditas unggulan meliputi padi organik, jagung manis, cabai, serta sayuran dataran tinggi." },
  { icon: Store, title: "UMKM", desc: "Industri rumahan kuliner khas, kerajinan tangan, dan tenun songket.",
    detail: "Sebanyak 78 unit UMKM aktif memproduksi rendang kemasan, keripik singkong, kerajinan anyaman pandan, hingga kain tenun motif Minangkabau yang dipasarkan hingga ke luar provinsi." },
  { icon: Mountain, title: "Wisata", desc: "Panorama alam, sungai jernih, dan situs budaya bernuansa Minangkabau.",
    detail: "Nagari Silongo memiliki potensi wisata alam berupa air terjun, sungai jernih, hamparan sawah, dan situs Rumah Gadang tua yang menjadi daya tarik wisatawan domestik maupun mancanegara." },
  { icon: Drama, title: "Budaya", desc: "Adat istiadat Minangkabau yang lestari dan kesenian tradisional aktif.",
    detail: "Tradisi adat Minangkabau seperti Batagak Pangulu, randai, saluang, dan silek masih dilestarikan secara turun-temurun oleh masyarakat nagari." },
  { icon: Beef, title: "Peternakan", desc: "Peternakan sapi, kerbau, kambing, dan unggas skala rumah tangga.",
    detail: "Sektor peternakan menjadi penopang ekonomi kedua setelah pertanian, dengan populasi sapi lokal yang terus berkembang melalui program inseminasi buatan." },
];

const WISATA = [
  { img: rumahGadangImg, title: "Rumah Gadang", desc: "Arsitektur ikonik Minangkabau" },
  { img: budayaImg, title: "Tradisi Minangkabau", desc: "Kesenian dan adat istiadat" },
  { img: sungaiImg, title: "Sungai Jernih", desc: "Wisata alam yang menyegarkan" },
  { img: sawahImg, title: "Hamparan Sawah", desc: "Panorama hijau khas nagari" },
  { img: budayaImg, title: "Kesenian Tradisional", desc: "Randai, saluang, dan silek" },
];

const BERITA = [
  { img: sawahImg, title: "Panen Raya Padi Organik di Jorong Koto Tuo", date: "12 Mei 2026",
    body: "Masyarakat Jorong Koto Tuo merayakan panen raya padi organik dengan hasil meningkat 18% dibanding musim sebelumnya. Wali Nagari mengapresiasi kerja keras kelompok tani serta dukungan dinas pertanian kabupaten. Hasil panen kali ini akan disalurkan ke pasar lokal dan sebagian diolah menjadi beras kemasan UMKM." },
  { img: budayaImg, title: "Festival Budaya Minangkabau Digelar Akhir Bulan", date: "5 Mei 2026",
    body: "Pemerintah Nagari Silongo akan menggelar Festival Budaya Minangkabau yang menampilkan randai, saluang, tari piring, dan pacu jawi mini. Acara terbuka untuk umum dan menjadi sarana promosi wisata budaya nagari." },
  { img: umkmImg, title: "Pelatihan UMKM Naik Kelas untuk Pengrajin Lokal", date: "28 April 2026",
    body: "Sebanyak 40 pelaku UMKM mengikuti pelatihan branding, pengemasan, dan pemasaran digital. Program ini hasil kolaborasi dengan Dinas Koperasi Sijunjung dan ditargetkan meningkatkan omzet pengrajin minimal 25%." },
];

const GALERI = [
  heroImg, rumahGadangImg, sawahImg, budayaImg, sungaiImg, umkmImg,
  sawahImg, rumahGadangImg, budayaImg,
];

function Home() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [pemerintahanIdx, setPemerintahanIdx] = useState<number | null>(null);
  const [potensiIdx, setPotensiIdx] = useState<number | null>(null);
  const [beritaIdx, setBeritaIdx] = useState<number | null>(null);
  const [wisataIdx, setWisataIdx] = useState<number | null>(null);
  const [galeriIdx, setGaleriIdx] = useState<number | null>(null);
  const [carouselIdx, setCarouselIdx] = useState(0);

  // Navbar scroll state
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Reveal on scroll
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("in");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12 },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  // Carousel auto-slide
  useEffect(() => {
    const t = setInterval(() => setCarouselIdx((i) => (i + 1) % WISATA.length), 4500);
    return () => clearInterval(t);
  }, []);

  // Lock body scroll when any modal open
  const anyOpen = aboutOpen || pemerintahanIdx !== null || potensiIdx !== null || beritaIdx !== null || wisataIdx !== null || galeriIdx !== null || menuOpen;
  useEffect(() => {
    document.body.style.overflow = anyOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [anyOpen]);

  const scrollTo = (id: string) => {
    setMenuOpen(false);
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* NAVBAR */}
      <header
        className={`fixed inset-x-0 top-0 z-40 transition-all duration-500 ${
          scrolled ? "glass shadow-[0_6px_30px_-15px_rgba(0,0,0,0.2)] py-3" : "bg-transparent py-5"
        }`}
      >
        <div className="container mx-auto flex items-center justify-between px-5 lg:px-10">
          <button onClick={() => scrollTo("beranda")} className="flex items-center gap-3 group">
            <div className={`grid h-11 w-11 place-items-center rounded-full transition-all duration-500 ${scrolled ? "bg-primary text-primary-foreground" : "bg-white/15 backdrop-blur text-white border border-white/30"}`}>
              <Landmark size={20} />
            </div>
            <div className="text-left leading-tight">
              <div className={`font-display text-lg font-semibold transition-colors ${scrolled ? "text-foreground" : "text-white"}`}>
                Nagari Silongo
              </div>
              <div className={`text-[11px] tracking-wider uppercase transition-colors ${scrolled ? "text-muted-foreground" : "text-white/70"}`}>
                Lubuk Tarok · Sijunjung
              </div>
            </div>
          </button>

          <nav className="hidden lg:flex items-center gap-1">
            {NAV.map((n) => (
              <button
                key={n.id}
                onClick={() => scrollTo(n.id)}
                className={`relative px-4 py-2 text-sm font-medium transition-colors group ${
                  scrolled ? "text-foreground/80 hover:text-primary" : "text-white/85 hover:text-white"
                }`}
              >
                {n.label}
                <span className="absolute left-4 right-4 -bottom-0.5 h-px scale-x-0 bg-gold transition-transform duration-300 group-hover:scale-x-100" />
              </button>
            ))}
          </nav>

          <button
            onClick={() => setMenuOpen(true)}
            className={`lg:hidden grid h-10 w-10 place-items-center rounded-md transition-colors ${scrolled ? "text-foreground" : "text-white"}`}
            aria-label="Buka menu"
          >
            <Menu size={22} />
          </button>
        </div>
      </header>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden fade-up">
          <div className="absolute inset-0 bg-primary/95 backdrop-blur-xl" />
          <div className="relative h-full flex flex-col">
            <div className="flex items-center justify-between px-6 py-5">
              <div className="text-white font-display text-xl">Menu</div>
              <button onClick={() => setMenuOpen(false)} className="text-white p-2" aria-label="Tutup">
                <X size={24} />
              </button>
            </div>
            <nav className="flex-1 flex flex-col items-center justify-center gap-3 px-6">
              {NAV.map((n) => (
                <button
                  key={n.id}
                  onClick={() => scrollTo(n.id)}
                  className="text-white/90 hover:text-gold text-xl font-display py-2 transition-colors"
                >
                  {n.label}
                </button>
              ))}
            </nav>
          </div>
        </div>
      )}

      {/* HERO */}
      <section id="beranda" className="relative min-h-[100svh] flex items-center justify-center overflow-hidden">
        <img
          src={heroImg}
          alt="Pemandangan Nagari Silongo"
          width={1920}
          height={1080}
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
        <div className="absolute inset-0 bg-primary/20 mix-blend-multiply" />

        <div className="relative z-10 container mx-auto px-6 text-center text-white">
          <div className="fade-up" style={{ animationDelay: "0.1s" }}>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 backdrop-blur px-4 py-1.5 text-xs tracking-[0.25em] uppercase text-white/90">
              <span className="h-1.5 w-1.5 rounded-full bg-gold" />
              Website Resmi Nagari
            </div>
          </div>
          <h1 className="mt-8 font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-semibold leading-[1.05] fade-up" style={{ animationDelay: "0.25s" }}>
            Selamat Datang di<br />
            <span className="text-gold">Nagari Silongo</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-base sm:text-lg text-white/85 fade-up" style={{ animationDelay: "0.4s" }}>
            Kecamatan Lubuk Tarok, Kabupaten Sijunjung, Sumatera Barat — bumi adat Minangkabau yang asri, ramah, dan terus tumbuh.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-3 fade-up" style={{ animationDelay: "0.55s" }}>
            <button
              onClick={() => scrollTo("profil")}
              className="group inline-flex items-center gap-2 rounded-full bg-gold px-7 py-3.5 text-sm font-medium text-gold-foreground shadow-[var(--shadow-gold)] hover:shadow-xl hover:-translate-y-0.5 transition-all"
            >
              Lihat Profil
              <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
            </button>
            <button
              onClick={() => scrollTo("wisata")}
              className="group inline-flex items-center gap-2 rounded-full border border-white/40 bg-white/5 backdrop-blur px-7 py-3.5 text-sm font-medium text-white hover:bg-white/15 hover:-translate-y-0.5 transition-all"
            >
              Jelajahi Desa
              <ChevronRight size={16} className="transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 text-white/70 text-[11px] tracking-[0.3em] uppercase float">
          Scroll
        </div>
      </section>

      {/* STATS */}
      <section className="relative -mt-16 z-20 px-5 lg:px-10">
        <div className="container mx-auto grid grid-cols-2 lg:grid-cols-4 gap-4">
          {STATS.map((s, i) => {
            const Icon = s.icon;
            return (
              <div
                key={s.label}
                className="reveal hover-lift bg-card rounded-2xl p-6 shadow-[var(--shadow-card)] border border-border/50"
                style={{ transitionDelay: `${i * 80}ms` }}
              >
                <div className="grid h-12 w-12 place-items-center rounded-xl bg-primary/10 text-primary mb-4">
                  <Icon size={22} />
                </div>
                <div className="font-display text-3xl font-semibold text-foreground">{s.value}</div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground mt-1">{s.suffix}</div>
                <div className="mt-2 text-sm text-foreground/80">{s.label}</div>
              </div>
            );
          })}
        </div>
      </section>

      {/* TENTANG */}
      <section id="profil" className="py-24 lg:py-32 px-5 lg:px-10">
        <div className="container mx-auto">
          <div className="ornament mb-12 reveal" />
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div className="reveal relative">
              <div className="relative overflow-hidden rounded-2xl aspect-[4/5] shadow-[var(--shadow-card)]">
                <img src={rumahGadangImg} alt="Rumah Gadang" width={1280} height={800} loading="lazy" className="h-full w-full object-cover hover:scale-105 transition-transform duration-700" />
              </div>
              <div className="absolute -bottom-6 -right-6 hidden md:block bg-gold text-gold-foreground rounded-xl px-5 py-4 shadow-[var(--shadow-gold)]">
                <div className="font-display text-2xl">Sejak 1908</div>
                <div className="text-xs uppercase tracking-wider">Warisan Adat</div>
              </div>
            </div>
            <div className="reveal">
              <div className="text-xs uppercase tracking-[0.3em] text-primary font-medium">Tentang Nagari</div>
              <h2 className="mt-3 font-display text-4xl lg:text-5xl font-semibold leading-tight">
                Warisan Minangkabau<br /><span className="text-wood">di jantung Sijunjung</span>
              </h2>
              <p className="mt-6 text-foreground/75 leading-relaxed">
                Nagari Silongo adalah salah satu nagari di Kecamatan Lubuk Tarok, Kabupaten Sijunjung, Provinsi Sumatera Barat. Terkenal dengan hamparan sawah yang hijau, sungai jernih, serta masyarakat yang menjunjung tinggi adat Minangkabau—"Adat Basandi Syarak, Syarak Basandi Kitabullah".
              </p>
              <p className="mt-4 text-foreground/75 leading-relaxed">
                Dengan lima jorong yang produktif, nagari ini menjadi pusat pertanian, peternakan, dan kerajinan tangan khas Minangkabau yang terus berkembang seiring zaman.
              </p>
              <button
                onClick={() => setAboutOpen(true)}
                className="mt-8 group inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground hover:shadow-[var(--shadow-soft)] hover:-translate-y-0.5 transition-all"
              >
                Baca Selengkapnya
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* PEMERINTAHAN */}
      <section id="pemerintahan" className="py-24 lg:py-32 px-5 lg:px-10 bg-secondary/60">
        <div className="container mx-auto">
          <SectionHeader eyebrow="Pemerintahan" title="Struktur Pemerintahan Nagari" sub="Pelayanan masyarakat yang amanah dan transparan, berlandaskan adat dan syarak." />
          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {PEMERINTAHAN.map((p, i) => {
              const Icon = p.icon;
              return (
                <button
                  key={p.role}
                  onClick={() => setPemerintahanIdx(i)}
                  className="reveal hover-lift text-left bg-card rounded-2xl p-7 border border-border/50 shadow-sm"
                  style={{ transitionDelay: `${i * 90}ms` }}
                >
                  <div className="mx-auto h-24 w-24 rounded-full bg-gradient-to-br from-primary to-wood grid place-items-center text-white shadow-[var(--shadow-soft)]">
                    <Icon size={34} />
                  </div>
                  <div className="mt-5 text-center">
                    <div className="text-xs uppercase tracking-[0.2em] text-gold-foreground/70">{p.role}</div>
                    <div className="font-display text-lg font-semibold mt-1">{p.name}</div>
                  </div>
                  <div className="mt-5 flex items-center justify-center gap-1 text-xs font-medium text-primary">
                    Lihat Profil <ChevronRight size={14} />
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* POTENSI */}
      <section id="potensi" className="py-24 lg:py-32 px-5 lg:px-10">
        <div className="container mx-auto">
          <SectionHeader eyebrow="Potensi" title="Kekayaan Nagari Silongo" sub="Sektor unggulan yang menjadi tulang punggung ekonomi dan kebanggaan masyarakat." />
          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {POTENSI.map((p, i) => {
              const Icon = p.icon;
              return (
                <button
                  key={p.title}
                  onClick={() => setPotensiIdx(i)}
                  className="reveal hover-lift text-left bg-card rounded-2xl p-7 border border-border/50 group"
                  style={{ transitionDelay: `${i * 80}ms` }}
                >
                  <div className="grid h-14 w-14 place-items-center rounded-xl bg-gold/15 text-wood group-hover:bg-gold group-hover:text-gold-foreground transition-colors">
                    <Icon size={26} />
                  </div>
                  <h3 className="mt-5 font-display text-2xl font-semibold">{p.title}</h3>
                  <p className="mt-2 text-sm text-foreground/70 leading-relaxed">{p.desc}</p>
                  <div className="mt-4 inline-flex items-center gap-1 text-xs font-medium text-primary">
                    Detail <ChevronRight size={14} />
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* WISATA & BUDAYA - CAROUSEL */}
      <section id="wisata" className="py-24 lg:py-32 px-5 lg:px-10 bg-primary text-primary-foreground overflow-hidden">
        <div className="container mx-auto">
          <div className="text-center reveal">
            <div className="text-xs uppercase tracking-[0.3em] text-gold">Wisata & Budaya</div>
            <h2 className="mt-3 font-display text-4xl lg:text-5xl font-semibold">Pesona Nagari Silongo</h2>
            <p className="mt-4 text-primary-foreground/70 max-w-2xl mx-auto">
              Keindahan alam dan kekayaan budaya Minangkabau yang lestari di setiap sudut nagari.
            </p>
            <div className="ornament mt-8 opacity-70" />
          </div>

          <div className="relative mt-12 reveal">
            <div className="relative aspect-[16/9] md:aspect-[21/9] rounded-2xl overflow-hidden shadow-2xl">
              {WISATA.map((w, i) => (
                <div
                  key={i}
                  className={`absolute inset-0 transition-opacity duration-1000 ${i === carouselIdx ? "opacity-100" : "opacity-0"}`}
                >
                  <img src={w.img} alt={w.title} className="h-full w-full object-cover" loading={i === 0 ? "eager" : "lazy"} />
                  <button onClick={() => setWisataIdx(i)} className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent flex items-end p-8 md:p-12 text-left">
                    <div>
                      <div className="text-gold text-xs uppercase tracking-[0.3em]">Destinasi</div>
                      <h3 className="font-display text-3xl md:text-5xl font-semibold mt-2 text-white">{w.title}</h3>
                      <p className="mt-2 text-white/80 max-w-lg">{w.desc}</p>
                    </div>
                  </button>
                </div>
              ))}
            </div>

            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={() => setCarouselIdx((i) => (i - 1 + WISATA.length) % WISATA.length)}
                className="grid h-11 w-11 place-items-center rounded-full border border-white/20 bg-white/5 hover:bg-white/15 transition-colors"
                aria-label="Sebelumnya"
              >
                <ChevronLeft size={18} />
              </button>
              <div className="flex gap-2">
                {WISATA.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCarouselIdx(i)}
                    className={`h-1.5 rounded-full transition-all ${i === carouselIdx ? "w-8 bg-gold" : "w-2 bg-white/30"}`}
                    aria-label={`Slide ${i + 1}`}
                  />
                ))}
              </div>
              <button
                onClick={() => setCarouselIdx((i) => (i + 1) % WISATA.length)}
                className="grid h-11 w-11 place-items-center rounded-full border border-white/20 bg-white/5 hover:bg-white/15 transition-colors"
                aria-label="Berikutnya"
              >
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* BERITA */}
      <section id="berita" className="py-24 lg:py-32 px-5 lg:px-10">
        <div className="container mx-auto">
          <SectionHeader eyebrow="Berita" title="Kabar Terkini Nagari" sub="Informasi resmi dan terbaru dari pemerintahan dan masyarakat Nagari Silongo." />
          <div className="mt-14 grid md:grid-cols-3 gap-6">
            {BERITA.map((b, i) => (
              <article
                key={i}
                className="reveal hover-lift bg-card rounded-2xl overflow-hidden border border-border/50 group"
                style={{ transitionDelay: `${i * 90}ms` }}
              >
                <div className="aspect-[16/10] overflow-hidden">
                  <img src={b.img} alt={b.title} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-700" />
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Calendar size={13} /> {b.date}
                  </div>
                  <h3 className="mt-3 font-display text-xl font-semibold leading-snug">{b.title}</h3>
                  <button
                    onClick={() => setBeritaIdx(i)}
                    className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary hover:gap-2 transition-all"
                  >
                    Baca Selengkapnya <ArrowRight size={14} />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* GALERI - MASONRY */}
      <section id="galeri" className="py-24 lg:py-32 px-5 lg:px-10 bg-secondary/60">
        <div className="container mx-auto">
          <SectionHeader eyebrow="Galeri" title="Potret Nagari Silongo" sub="Momen, kegiatan, dan keindahan nagari dalam bingkai foto." />
          <div className="mt-14 columns-2 md:columns-3 lg:columns-4 gap-4 space-y-4">
            {GALERI.map((g, i) => (
              <button
                key={i}
                onClick={() => setGaleriIdx(i)}
                className="reveal block w-full overflow-hidden rounded-xl group break-inside-avoid"
                style={{ transitionDelay: `${i * 50}ms` }}
              >
                <img
                  src={g}
                  alt={`Galeri ${i + 1}`}
                  loading="lazy"
                  className="w-full h-auto object-cover group-hover:scale-105 transition-transform duration-700"
                  style={{ aspectRatio: i % 3 === 0 ? "3/4" : i % 3 === 1 ? "4/3" : "1/1" }}
                />
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* KONTAK */}
      <section id="kontak" className="py-24 lg:py-32 px-5 lg:px-10">
        <div className="container mx-auto">
          <SectionHeader eyebrow="Kontak" title="Hubungi Kami" sub="Kami siap melayani dan menerima masukan dari masyarakat." />
          <div className="mt-14 grid lg:grid-cols-2 gap-8">
            <div className="reveal space-y-5">
              <ContactRow icon={MapPin} title="Alamat Kantor Nagari" body="Jl. Raya Silongo, Kec. Lubuk Tarok, Kab. Sijunjung, Sumatera Barat 27563" />
              <ContactRow icon={Phone} title="Telepon" body="(0754) 123-4567" />
              <ContactRow icon={Mail} title="Email" body="info@nagarisilongo.id" />
              <ContactRow icon={MessageCircle} title="WhatsApp" body="+62 812-3456-7890" />
            </div>
            <div className="reveal rounded-2xl overflow-hidden border border-border/50 shadow-[var(--shadow-card)] aspect-[4/3] lg:aspect-auto">
              <iframe
                title="Lokasi Nagari Silongo"
                src="https://www.google.com/maps?q=Lubuk+Tarok,+Sijunjung,+Sumatera+Barat&output=embed"
                className="h-full w-full"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-primary text-primary-foreground pt-16 pb-8 px-5 lg:px-10">
        <div className="container mx-auto grid md:grid-cols-4 gap-10">
          <div className="md:col-span-2">
            <div className="flex items-center gap-3">
              <div className="grid h-11 w-11 place-items-center rounded-full bg-gold text-gold-foreground">
                <Landmark size={20} />
              </div>
              <div>
                <div className="font-display text-xl">Nagari Silongo</div>
                <div className="text-xs uppercase tracking-wider text-primary-foreground/70">Lubuk Tarok · Sijunjung</div>
              </div>
            </div>
            <p className="mt-5 text-sm text-primary-foreground/70 max-w-md leading-relaxed">
              Website resmi Pemerintah Nagari Silongo. Memberikan informasi profil, pemerintahan, potensi, dan kegiatan nagari untuk masyarakat luas.
            </p>
            <div className="mt-6 flex gap-3">
              {[Facebook, Instagram, Youtube].map((Ic, i) => (
                <a key={i} href="#" className="grid h-9 w-9 place-items-center rounded-full border border-white/20 hover:bg-gold hover:text-gold-foreground hover:border-gold transition-colors" aria-label="Sosial Media">
                  <Ic size={16} />
                </a>
              ))}
            </div>
          </div>
          <div>
            <div className="text-gold text-xs uppercase tracking-[0.25em] mb-4">Menu Cepat</div>
            <ul className="space-y-2 text-sm text-primary-foreground/75">
              {NAV.slice(0, 5).map((n) => (
                <li key={n.id}>
                  <button onClick={() => scrollTo(n.id)} className="hover:text-gold transition-colors">
                    {n.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <div className="text-gold text-xs uppercase tracking-[0.25em] mb-4">Lainnya</div>
            <ul className="space-y-2 text-sm text-primary-foreground/75">
              {NAV.slice(5).map((n) => (
                <li key={n.id}>
                  <button onClick={() => scrollTo(n.id)} className="hover:text-gold transition-colors">
                    {n.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="ornament mt-12 opacity-40" />
        <div className="container mx-auto mt-6 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-primary-foreground/60">
          <div>© {new Date().getFullYear()} Pemerintah Nagari Silongo. Hak cipta dilindungi.</div>
          <div>Dibuat dengan dedikasi untuk masyarakat Nagari Silongo.</div>
        </div>
      </footer>

      {/* WHATSAPP FLOAT */}
      <a
        href="https://wa.me/6281234567890"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-30 grid h-14 w-14 place-items-center rounded-full bg-[#25D366] text-white shadow-2xl hover:scale-110 transition-transform float"
        aria-label="Chat WhatsApp"
      >
        <MessageCircle size={26} />
      </a>

      {/* MODALS */}
      <Modal open={aboutOpen} onClose={() => setAboutOpen(false)} title="Tentang Nagari Silongo">
        <img src={rumahGadangImg} alt="" loading="lazy" className="w-full h-56 object-cover rounded-xl mb-5" />
        <p className="text-foreground/80 leading-relaxed">
          Nagari Silongo terletak di Kecamatan Lubuk Tarok, Kabupaten Sijunjung, Provinsi Sumatera Barat. Nagari ini telah menjadi bagian penting dari kebudayaan Minangkabau sejak awal abad ke-20 dan terus mempertahankan nilai-nilai adat hingga saat ini.
        </p>
        <h4 className="font-display text-xl mt-6 mb-2">Sejarah</h4>
        <p className="text-foreground/80 leading-relaxed">
          Berdasarkan tambo dan tutur penghulu adat, Nagari Silongo didirikan oleh perantauan keturunan Pariangan yang membuka lahan di tepian sungai. Nama "Silongo" konon berasal dari bahasa setempat yang merujuk pada bentuk geografis lembah yang menyerupai mangkuk besar.
        </p>
        <h4 className="font-display text-xl mt-6 mb-2">Geografi</h4>
        <p className="text-foreground/80 leading-relaxed">
          Luas wilayah ±32,4 km² yang terdiri dari lima jorong: Jorong Koto Tuo, Jorong Sungai Lansek, Jorong Padang Tarok, Jorong Bukit Buai, dan Jorong Tanjung. Sebagian besar lahan adalah persawahan dan perkebunan rakyat.
        </p>
        <h4 className="font-display text-xl mt-6 mb-2">Visi Misi</h4>
        <p className="text-foreground/80 leading-relaxed">
          Visi: "Mewujudkan Nagari Silongo yang Maju, Berbudaya, dan Sejahtera Berlandaskan Adat Basandi Syarak, Syarak Basandi Kitabullah."
        </p>
      </Modal>

      <Modal open={pemerintahanIdx !== null} onClose={() => setPemerintahanIdx(null)} title={pemerintahanIdx !== null ? PEMERINTAHAN[pemerintahanIdx].role : ""}>
        {pemerintahanIdx !== null && (() => {
          const p = PEMERINTAHAN[pemerintahanIdx];
          const Icon = p.icon;
          return (
            <div className="text-center">
              <div className="mx-auto h-32 w-32 rounded-full bg-gradient-to-br from-primary to-wood grid place-items-center text-white shadow-[var(--shadow-soft)] mb-5">
                <Icon size={48} />
              </div>
              <div className="text-xs uppercase tracking-[0.25em] text-primary">{p.role}</div>
              <h3 className="font-display text-2xl font-semibold mt-2">{p.name}</h3>
              <div className="ornament my-5 opacity-60" />
              <p className="text-foreground/80 leading-relaxed text-left">{p.bio}</p>
            </div>
          );
        })()}
      </Modal>

      <Modal open={potensiIdx !== null} onClose={() => setPotensiIdx(null)} title={potensiIdx !== null ? POTENSI[potensiIdx].title : ""}>
        {potensiIdx !== null && (() => {
          const p = POTENSI[potensiIdx];
          const Icon = p.icon;
          return (
            <div>
              <div className="grid h-16 w-16 place-items-center rounded-xl bg-gold/15 text-wood mb-5">
                <Icon size={32} />
              </div>
              <h3 className="font-display text-2xl font-semibold">{p.title}</h3>
              <p className="mt-2 text-sm text-foreground/60">{p.desc}</p>
              <div className="ornament my-5 opacity-60" />
              <p className="text-foreground/80 leading-relaxed">{p.detail}</p>
            </div>
          );
        })()}
      </Modal>

      <Modal open={beritaIdx !== null} onClose={() => setBeritaIdx(null)} title={beritaIdx !== null ? BERITA[beritaIdx].title : ""}>
        {beritaIdx !== null && (() => {
          const b = BERITA[beritaIdx];
          return (
            <div>
              <img src={b.img} alt="" loading="lazy" className="w-full h-64 object-cover rounded-xl mb-5" />
              <div className="flex items-center gap-2 text-xs text-muted-foreground"><Calendar size={13} /> {b.date}</div>
              <h3 className="font-display text-2xl font-semibold mt-2">{b.title}</h3>
              <div className="ornament my-5 opacity-60" />
              <p className="text-foreground/80 leading-relaxed">{b.body}</p>
            </div>
          );
        })()}
      </Modal>

      <Lightbox open={wisataIdx !== null} onClose={() => setWisataIdx(null)} src={wisataIdx !== null ? WISATA[wisataIdx].img : ""} caption={wisataIdx !== null ? WISATA[wisataIdx].title : ""} />
      <Lightbox open={galeriIdx !== null} onClose={() => setGaleriIdx(null)} src={galeriIdx !== null ? GALERI[galeriIdx] : ""} caption={galeriIdx !== null ? `Galeri ${galeriIdx + 1}` : ""} />
    </div>
  );
}

function SectionHeader({ eyebrow, title, sub }: { eyebrow: string; title: string; sub: string }) {
  return (
    <div className="text-center max-w-2xl mx-auto reveal">
      <div className="text-xs uppercase tracking-[0.3em] text-primary font-medium">{eyebrow}</div>
      <h2 className="mt-3 font-display text-4xl lg:text-5xl font-semibold leading-tight">{title}</h2>
      <p className="mt-4 text-foreground/65">{sub}</p>
      <div className="ornament mt-6" />
    </div>
  );
}

function ContactRow({ icon: Icon, title, body }: { icon: React.ComponentType<{ size?: number }>; title: string; body: string }) {
  return (
    <div className="flex items-start gap-4 bg-card rounded-2xl p-5 border border-border/50 hover-lift">
      <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
        <Icon size={20} />
      </div>
      <div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{title}</div>
        <div className="mt-1 font-medium text-foreground">{body}</div>
      </div>
    </div>
  );
}

function Modal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: React.ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    if (open) window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 fade-up" style={{ animationDuration: "0.35s" }}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-md" onClick={onClose} />
      <div ref={ref} className="relative z-10 bg-card text-card-foreground w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl shadow-2xl border border-border/50">
        <div className="sticky top-0 z-10 flex items-center justify-between gap-4 px-6 py-4 border-b border-border/50 bg-card/95 backdrop-blur">
          <h3 className="font-display text-xl font-semibold pr-8">{title}</h3>
          <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-full hover:bg-muted transition-colors" aria-label="Tutup">
            <X size={18} />
          </button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}

function Lightbox({ open, onClose, src, caption }: { open: boolean; onClose: () => void; src: string; caption: string }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    if (open) window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 fade-up" style={{ animationDuration: "0.3s" }}>
      <div className="absolute inset-0 bg-black/90 backdrop-blur-md" onClick={onClose} />
      <button onClick={onClose} className="absolute top-5 right-5 z-10 grid h-11 w-11 place-items-center rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors" aria-label="Tutup">
        <X size={20} />
      </button>
      <div className="relative z-10 max-w-6xl w-full">
        <img src={src} alt={caption} className="w-full max-h-[85vh] object-contain rounded-lg" />
        <div className="mt-4 text-center text-white/85 font-display text-lg">{caption}</div>
      </div>
    </div>
  );
}
